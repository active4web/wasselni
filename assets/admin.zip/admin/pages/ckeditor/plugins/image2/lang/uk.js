/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'uk', {
	alt: 'Альтернативний текст',
	btnUpload: 'Надіслати на сервер',
	captioned: 'Підписане зображення',
	captionPlaceholder: 'Заголовок',
	infoTab: 'Інформація про зображення',
	lockRatio: 'Зберегти пропорції',
	menu: 'Властивості зображення',
	pathName: 'Зображення',
	pathNameCaption: 'заголовок',
	resetSize: 'Очистити поля розмірів',
	resizer: 'Клікніть та потягніть для зміни розмірів',
	title: 'Властивості зображення',
	uploadTab: 'Надіслати',
	urlMissing: 'Вкажіть URL зображення.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
